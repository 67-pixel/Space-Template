﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.Temp.gorillatag.menutemplate";
        public const string Name = "SPACE TEMP";
        public const string Description = "Created by @JJ with love <3";
        public const string Version = "1.0.0";
    }
}
