![Mod Menu Banner](https://media.discordapp.net/attachments/1345742664355680547/1358808283309408538/image.png?ex=67f53054&is=67f3ded4&hm=fa5681cc7534d6ddba257449f26248166ec38a3cc9b54a22788459bedacdf566&=&format=webp&quality=lossless&width=1522&height=856)  

## Aether Untilted Template

this was originally made by shiba pretty sure

## 💡 Suggestions  
If you’d like me to create more templates, let me know!  
Join our **Discord server** and drop your suggestions:  
👉 [Join Here](https://discord.gg/KXABTbrQx2)  

## 📜 Disclaimer  
This is for **educational purposes only**. I am not responsible for how this is used.  

This is also my first ever template i made about a few months ago

## ❤️ Credits  
Credits to **iidk** for the main template it made it easier to create menus with it. 

**https://discord.gg/KXABTbrQx2**
